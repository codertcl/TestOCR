﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Tesseract;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
namespace TestOcr
{
    public partial class Form1 : Form
    {
        //文件名
        private string curFileName;
        //图像对象
        private System.Drawing.Bitmap curBitmap;

        public Form1()
        {
            InitializeComponent();
        }

        //图片灰度化
        public static Bitmap ToGray(Bitmap bmp)
        {
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    //获取该点的像素的RGB的颜色
                    Color color = bmp.GetPixel(i, j);
                    //利用公式计算灰度值
                    int gray = (int)(color.R * 0.3 + color.G * 0.59 + color.B * 0.11);
                    Color newColor = Color.FromArgb(gray, gray, gray);
                    bmp.SetPixel(i, j, newColor);
                }
            }
            return bmp;
        }


        //图像二值化：取图片的平均灰度作为阈值，低于该值的全都为0，高于该值的全都为255
        public static Bitmap ConvertTo1Bpp(Bitmap bmp)
        {
            int average = 0;
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color color = bmp.GetPixel(i, j);
                    average += color.B;
                }
            }

            average = (int)average / (bmp.Width * bmp.Height);

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    //获取该点的像素的RGB的颜色
                    Color color = bmp.GetPixel(i, j);
                    int value = 255 - color.B;
                    Color newColor = value > average ? Color.FromArgb(0, 0, 0) : Color.FromArgb(255, 255, 255);
                    bmp.SetPixel(i, j, newColor);
                }
            }
            return bmp;
        }



        //打开图片
        private void button1_Click(object sender, EventArgs e)
        {
            //创建OpenFileDialog
            OpenFileDialog opnDlg = new OpenFileDialog();
            //为图像选择一个筛选器
            opnDlg.Filter = "所有图像文件|*.bmp;*.pcx;*.png;*.tiff;*.jpg;*.gif;*.jpeg;*.PNG;" +
                "*.tif;*.ico;*.dxf;*.cgm;*.cdr;*.wmf;*.eps;*.emf|" +
                "位图(*.bmp;*.jpg;*.png;...)|*.bmp;*.pcx;*.png;*.jpg;*.gif;*.tif;*.ico|" +
                "矢量图(*.wmf;*.eps;*.emf;..)|*.dxf;*.cgm;*.cdr;*.wmf;*.eps;*.emf";
            //设置对话框标题
            opnDlg.Title = "打开图像文件";

            //如果选择的结果为打开，则选定文件
            if (opnDlg.ShowDialog() == DialogResult.OK)
            {
                //读取当前选中的文件地址             
                curFileName = opnDlg.FileName;
                this.pictureBox1.Load(curFileName);
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;//加载的图片自适应picrurebox大小
            }
            Invalidate();
        }


        //文字识别
        private void button2_Click(object sender, EventArgs e)
        {
            Array traindata = Array.CreateInstance(typeof(string), 10);
            traindata.SetValue("test",0);
            traindata.SetValue("chi_sim_vert",1);
            traindata.SetValue("chi_tra",2);
            traindata.SetValue("chi_tra_vert",3);
            traindata.SetValue("eng",4);
            traindata.SetValue("jpn", 5);
            traindata.SetValue("chi_my", 6);//手写数字


            string train = (string)traindata.GetValue(listBox1.SelectedIndex);
            var img = new Bitmap(curFileName);    //需要识别的图片
         

            var ocr = new TesseractEngine(@"D:\Tesseract\tessdata", train, EngineMode.Default);   
            var page = ocr.Process(img);
            this.textBox1.Text = page.GetText();
        }
    }
}
